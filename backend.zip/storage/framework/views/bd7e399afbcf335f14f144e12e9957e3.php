<?php echo e($slot); ?>

<?php /**PATH G:\SKRIPSI\PROJEK-SIAP\backend\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>