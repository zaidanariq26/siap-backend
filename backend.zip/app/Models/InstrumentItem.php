<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InstrumentItem extends Model
{
	protected $primaryKey = "id_instrument_item";
	protected $guarded = ["id_instrument_item"];
}
