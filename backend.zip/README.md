# 🧩 SIAP Backend — Sistem Informasi Aktivitas PKL

**SIAP (Sistem Informasi Aktivitas PKL)** adalah aplikasi berbasis web yang digunakan untuk mencatat dan memantau aktivitas siswa selama menjalani Praktik Kerja Lapangan (PKL). Proyek ini adalah bagian backend yang dibangun menggunakan [Laravel](https://laravel.com/docs/11.x).

## Teknologi yang Digunakan

- **Laravel** (PHP Framework)
- **MySQL** (Database)
